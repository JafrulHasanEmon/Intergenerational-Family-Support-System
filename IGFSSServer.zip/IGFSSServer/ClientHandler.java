package com.mycompany.igfssserver;

import com.mycompany.IGFSS.model.Member;
import com.mycompany.IGFSS.model.OlderCouple;
import com.mycompany.IGFSS.model.YoungFamily;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Handles client requests in a separate thread.
 */
class ClientHandler implements Runnable {

    private Socket clientSocket;

    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {

        try (ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream()); ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())) {
            String action = (String) in.readObject();
            System.out.println("Received action: " + action);
            switch (action) {

                case "REGISTER_OLDER":
                    // Receive the OlderCouple object from the client
                    OlderCouple olderCouple = (OlderCouple) in.readObject();
                    System.out.println("Received: " + olderCouple);
                    saveToFile(olderCouple, IGFSSServer.OLDER_COUPLES_FILE);

                    // Process the object (For now, just send a success message)
                    out.writeObject("Older couple registered successfully!");
                    break;

                case "VIEW_OLDER":
                    handleViewMember(in, out);
                    break;

                case "REGISTER_YOUNG":
                    YoungFamily youngFamily = (YoungFamily) in.readObject();
                    System.out.println("Received: " + youngFamily);
                    saveToFile(youngFamily, IGFSSServer.YOUNG_FAMILIES_FILE);

                    // Process the object (For now, just send a success message)
                    out.writeObject("Young family registered successfully!");
                    break;

                case "VIEW_YOUNG":
                    handleViewYoung(in, out);
                    break;

                default:
                    out.writeObject("Invalid action");
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void handleViewMember(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
        List<Member> members = loadAllMembers("Older");  // Load all members from both files
        out.writeObject(members);  // Send the list of members
    }

    private void handleViewYoung(ObjectInputStream in, ObjectOutputStream out) throws IOException, ClassNotFoundException {
        List<Member> youngMembers = loadAllMembers("Young");  // Load all members from both files
        out.writeObject(youngMembers);  // Send the list of members
    }

    private List<Member> loadAllMembers(String type) throws IOException {
        List<Member> allMembers = new ArrayList<>();
        if (type == "Older") {
            List<Member> olderCouples = loadAllMembersFromFile(IGFSSServer.OLDER_COUPLES_FILE);  // Load older couples
            allMembers.addAll(olderCouples);  // Add older couples to the list

        } else {

            List<Member> youngFamilies = loadAllMembersFromFile(IGFSSServer.YOUNG_FAMILIES_FILE);  // Load young families
            allMembers.addAll(youngFamilies);  // Add young families to the list

        }

        return allMembers;
    }

    private List<Member> loadAllMembersFromFile(String filename) throws IOException {
        List<Member> members = new ArrayList<>();
        try (
                FileInputStream fileIn = new FileInputStream(filename); ObjectInputStream in = new ObjectInputStream(fileIn)) {

            while (true) {
                try {
                    Object obj = in.readObject();
                    if (obj instanceof Member) {
                        members.add((Member) obj);
                    }
                } catch (EOFException e) {
                    // End of file reached
                    break;
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
        return members;
    }

    private void saveToFile(Object member, String filename) {
        boolean append = new File(filename).exists(); // Check if file already exists

        try (
                FileOutputStream fileOut = new FileOutputStream(filename, true); ObjectOutputStream out = append ? new AppendableObjectOutputStream(fileOut)
                        : new ObjectOutputStream(fileOut)) {
            out.writeObject(member);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
