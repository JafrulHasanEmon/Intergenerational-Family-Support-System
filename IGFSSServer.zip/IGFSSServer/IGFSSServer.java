/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.igfssserver;

/**
 *
 * @author Jafrul Hasan
 */
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.*;

public class IGFSSServer {
    private static final int PORT = 8080;
    static final String OLDER_COUPLES_FILE = "older_couples.dat";
    static final String YOUNG_FAMILIES_FILE = "young_families.dat";
    private static final ExecutorService threadPool = Executors.newCachedThreadPool();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running on port " + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                threadPool.submit(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
