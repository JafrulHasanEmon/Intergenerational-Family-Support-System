/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.IGFSS.model;

/**
 *
 * @author Jafrul Hasan
 */
import java.io.Serializable;

public abstract class Member implements Serializable {
    private static final long serialVersionUID = 1L;
    private String fid; // Family Identification Number

    public Member(String fid) {
        this.fid = fid;
    }

    public String getFid() {
        return fid;
    }
}
