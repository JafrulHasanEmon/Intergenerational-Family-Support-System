/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.igfssserver;

/**
 *
 * @author Jafrul Hasan
 */
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

// Custom ObjectOutputStream to skip writing the header for appending objects
public class AppendableObjectOutputStream extends ObjectOutputStream {

    public AppendableObjectOutputStream(OutputStream out) throws IOException {
        super(out);
    }

    @Override
    protected void writeStreamHeader() throws IOException {
        // Skip writing a header for appending objects
        reset();
    }
}
