/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.IGFSS.model;

/**
 *
 * @author Jafrul Hasan
 */
import java.io.Serializable;

public class OlderCouple extends Member implements Serializable {

    private static final long serialVersionUID = 1L;

    private String spouse1Name;
    private String spouse2Name;
    private String phoneNumber;
    private String emailAddress;
    private String residentialAddress;
    private int yearsMarried;

    // Constructor
    public OlderCouple(String fid, String spouse1Name, String spouse2Name, String phoneNumber, String emailAddress, String residentialAddress, int yearsMarried) {
        super(fid); // Initialize FID in the parent class
        this.spouse1Name = spouse1Name;
        this.spouse2Name = spouse2Name;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.residentialAddress = residentialAddress;

        if (yearsMarried < 20) {
            throw new IllegalArgumentException("Years married must be at least 20 years.");
        }
        this.yearsMarried = yearsMarried;
    }

    // Getters
    public String getSpouse1Name() {
        return spouse1Name;
    }

    public String getSpouse2Name() {
        return spouse2Name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getResidentialAddress() {
        return residentialAddress;
    }

    public int getYearsMarried() {
        return yearsMarried;
    }

    @Override
    public String toString() {
        return "FID: " + getFid() + ", Spouse 1: " + spouse1Name + ", Spouse 2: " + spouse2Name
                + ", Phone: " + phoneNumber + ", Email: " + emailAddress
                + ", Address: " + residentialAddress + ", Years Married: " + yearsMarried;
    }
}
