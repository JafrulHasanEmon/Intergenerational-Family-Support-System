///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
package com.mycompany.IGFSS.model;

import com.mycompany.IGFSS.model.Member;
//
///**
// *
// * @author Jafrul Hasan
// */

import java.io.Serializable;

public class YoungFamily extends Member implements Serializable {

    private static final long serialVersionUID = 1L;

    private String spouse1Name;
    private String spouse2Name;
    private String phoneNumber;
    private String emailAddress;
    private String residentialAddress;
    private String child1Gender;
    private int child1Age;
    private String child2Gender;
    private int child2Age;
    private String child3Gender;
    private int child3Age;
    private String child4Gender;
    private int child4Age;

    // Constructor
    public YoungFamily(String fid, String spouse1Name, String spouse2Name, String phoneNumber, 
                       String emailAddress, String residentialAddress, 
                       String child1Gender, int child1Age, String child2Gender, int child2Age,
                       String child3Gender, int child3Age, String child4Gender, int child4Age) {
        super(fid); // Initialize FID in the parent class
        this.spouse1Name = spouse1Name;
        this.spouse2Name = spouse2Name;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.residentialAddress = residentialAddress;
        this.child1Gender = child1Gender;
        this.child1Age = child1Age;
        this.child2Gender = child2Gender;
        this.child2Age = child2Age;
        this.child3Gender = child3Gender;
        this.child3Age = child3Age;
        this.child4Gender = child4Gender;
        this.child4Age = child4Age;
    }

    // Getters
    public String getSpouse1Name() {
        return spouse1Name;
    }

    public String getSpouse2Name() {
        return spouse2Name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getResidentialAddress() {
        return residentialAddress;
    }

    public String getChild1Gender() {
        return child1Gender;
    }

    public int getChild1Age() {
        return child1Age;
    }

    public String getChild2Gender() {
        return child2Gender;
    }

    public int getChild2Age() {
        return child2Age;
    }

    public String getChild3Gender() {
        return child3Gender;
    }

    public int getChild3Age() {
        return child3Age;
    }

    public String getChild4Gender() {
        return child4Gender;
    }

    public int getChild4Age() {
        return child4Age;
    }

    @Override
    public String toString() {
        return "FID: " + getFid() + ", Spouse 1: " + spouse1Name + ", Spouse 2: " + spouse2Name
                + ", Phone: " + phoneNumber + ", Email: " + emailAddress
                + ", Address: " + residentialAddress 
                + ", Child 1: " + child1Gender + " (Age: " + child1Age + ")"
                + ", Child 2: " + child2Gender + " (Age: " + child2Age + ")"
                + ", Child 3: " + child3Gender + " (Age: " + child3Age + ")"
                + ", Child 4: " + child4Gender + " (Age: " + child4Age + ")";
    }
}
