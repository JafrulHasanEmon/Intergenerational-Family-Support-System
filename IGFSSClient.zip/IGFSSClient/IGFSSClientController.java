package com.mycompany.IGFSS.controller;

import com.mycompany.IGFSS.model.OlderCouple;
import com.mycompany.IGFSS.model.YoungFamily;
//import com.mycompany.drs.model.YoungFamily;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;
import static java.lang.System.in;
import static java.lang.System.out;
import java.net.Socket;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.stage.Stage;

public class IGFSSClientController {

    private Stage primaryStage;

    // Method to set the primary stage
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 8080;
    @FXML
    private TextField fidField;
    @FXML
    private TextField spouse1Field;
    @FXML
    private TextField spouse2Field;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField yearsMarriedField;
    @FXML
    private Label statusLabel;

    private ObservableList<OlderCouple> olderCoupleList = FXCollections.observableArrayList();
    @FXML
    private ListView<String> olderCoupleListView;

    @FXML
    private TextField youngFamilyFidField;

    @FXML
    private TextField youngSpouse1Field;

    @FXML
    private TextField youngSpouse2Field;

    @FXML
    private TextField youngPhoneField;

    @FXML
    private TextField youngEmailField;

    @FXML
    private TextField youngAddressField;

// Add the other fields for children details
    @FXML
    private TextField child1GenderField;
    @FXML
    private TextField child1AgeField;
    @FXML
    private TextField child2GenderField;
    @FXML
    private TextField child2AgeField;
    @FXML
    private TextField child3GenderField;
    @FXML
    private TextField child3AgeField;
    @FXML
    private TextField child4GenderField;
    @FXML
    private TextField child4AgeField;
    @FXML
    private Label youngFamilyStatusLabel;
    @FXML
    private ListView<String> youngCoupleListView;

    @FXML
    private void registerOlderCouple() {
        try {
            // Collect input data from the form fields
            String fid = fidField.getText();
            String spouse1 = spouse1Field.getText();
            String spouse2 = spouse2Field.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            String address = addressField.getText();
            int yearsMarried = Integer.parseInt(yearsMarriedField.getText());

            // Validate the input data (years married must be >= 20)
            if (yearsMarried < 20) {
                statusLabel.setText("Error: Years married must be at least 20.");
                return;
            }

            // Create an OlderCouple object
            OlderCouple olderCouple = new OlderCouple(fid, spouse1, spouse2, phone, email, address, yearsMarried);

            // Send to the server
            try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT); ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream()); ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

                // Send object to the server
                out.writeObject("REGISTER_OLDER"); // Command to register an older couple
                out.writeObject(olderCouple); // Send the OlderCouple object

                // Receive server response
                String response = (String) in.readObject();
                statusLabel.setText(response); // Show the response from the server
                clearForm();

            } catch (IOException | ClassNotFoundException e) {
                statusLabel.setText("Error: Unable to communicate with server.");
                e.printStackTrace();
            }
        } catch (NumberFormatException e) {
            statusLabel.setText("Error: Invalid input for Years Married.");
        }
    }

    @FXML
    private void viewOlderCouples() {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT); ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream()); ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            // Send request to view older couples
            out.writeObject("VIEW_OLDER");

            // Receive the list of older couples from the server
            List<OlderCouple> olderCouples = (List<OlderCouple>) in.readObject();

            // Clear the existing items in the list view
            olderCoupleListView.getItems().clear();

            // Populate the ListView with the received data
            for (OlderCouple couple : olderCouples) {
                olderCoupleListView.getItems().add(couple.toString()); // Assuming toString() provides a readable format
            }

            statusLabel.setText("Data loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            statusLabel.setText("Error: Unable to connect to server.");
            e.printStackTrace();
        }
    }

    @FXML
    private void registerYoungFamily() {
        // Prompt for details and register a young family
        try {
            // Collect input data from the form fields
            String fid = youngFamilyFidField.getText();
            String spouse1 = youngSpouse1Field.getText();
            String spouse2 = youngSpouse2Field.getText();
            String phone = youngPhoneField.getText();
            String email = youngEmailField.getText();
            String address = youngAddressField.getText();

            // Validate mandatory fields
            if (isNullOrEmpty(fid)) {
                youngFamilyStatusLabel.setText("Error: Family ID is required.");
                return;
            }
            if (isNullOrEmpty(spouse1)) {
                youngFamilyStatusLabel.setText("Error: Spouse 1 name is required.");
                return;
            }
            if (isNullOrEmpty(spouse2)) {
                youngFamilyStatusLabel.setText("Error: Spouse 2 name is required.");
                return;
            }
            if (isNullOrEmpty(phone)) {
                youngFamilyStatusLabel.setText("Error: Phone number is required.");
                return;
            }
            if (isNullOrEmpty(email)) {
                youngFamilyStatusLabel.setText("Error: Email is required.");
                return;
            }
            if (isNullOrEmpty(address)) {
                youngFamilyStatusLabel.setText("Error: Address is required.");
                return;
            }

            // Validate and parse child details
            int child1Age = parseChildAge(child1AgeField.getText(), "Child 1");
            String child1Gender = getGenderOrDefault(child1GenderField.getText());
            int child2Age = parseChildAge(child2AgeField.getText(), "Child 2");
            String child2Gender = getGenderOrDefault(child2GenderField.getText());
            int child3Age = parseChildAge(child3AgeField.getText(), "Child 3");
            String child3Gender = getGenderOrDefault(child3GenderField.getText());
            int child4Age = parseChildAge(child4AgeField.getText(), "Child 4");
            String child4Gender = getGenderOrDefault(child4GenderField.getText());

            // Create the YoungFamily object
            YoungFamily youngFamily = new YoungFamily(fid, spouse1, spouse2, phone, email, address,
                    child1Gender, child1Age, child2Gender, child2Age,
                    child3Gender, child3Age, child4Gender, child4Age);

            // Run server communication in a background thread
            Task<Void> registerTask = new Task<>() {
                @Override
                protected Void call() throws Exception {
                    try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT); ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream()); ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

                        // Send object to the server
                        out.writeObject("REGISTER_YOUNG"); // Command to register a young family
                        out.writeObject(youngFamily); // Send the YoungFamily object

                        // Receive server response
                        String response = (String) in.readObject();

                        // Update UI on the JavaFX Application thread
                        updateMessage(response);
                    }
                    return null;
                }
            };

            // Update the status label on success or failure
            registerTask.setOnSucceeded(event -> {
                youngFamilyStatusLabel.setText(registerTask.getMessage());
                clearForm();
            });
            registerTask.setOnFailed(event -> {
                youngFamilyStatusLabel.setText("Error: Unable to communicate with server.");
                registerTask.getException().printStackTrace();
            });

            // Run the task in a new thread
            new Thread(registerTask).start();

        } catch (IllegalArgumentException e) {
            youngFamilyStatusLabel.setText(e.getMessage());
        }
    }
    // Utility method to check for null or empty fields

    private boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    private int parseChildAge(String ageText, String childName) throws IllegalArgumentException {
        if (ageText != null && !ageText.trim().isEmpty()) {
            int age = Integer.parseInt(ageText);
            if (age < 0) {
                throw new IllegalArgumentException("Error: " + childName + " age cannot be negative.");
            }
            return age;
        }
        return 0; // Default value for empty field
    }

    private String getGenderOrDefault(String gender) {
        return (gender == null || gender.trim().isEmpty()) ? "Unknown" : gender;
    }

    @FXML
    private void viewYoungFamilies() {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT); ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream()); ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            // Send request to view older couples
            out.writeObject("VIEW_YOUNG");

            // Receive the list of older couples from the server
            List<YoungFamily> youngFamily = (List<YoungFamily>) in.readObject();

            // Clear the existing items in the list view
            youngCoupleListView.getItems().clear();

            // Populate the ListView with the received data
            for (YoungFamily young : youngFamily) {
                youngCoupleListView.getItems().add(young.toString()); // Assuming toString() provides a readable format
            }

            youngFamilyStatusLabel.setText("Data loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            youngFamilyStatusLabel.setText("Error: Unable to communicate with server.");
            e.printStackTrace();
        }

    }

    private void clearForm() {
        // Clear the fields for the older couple form
        fidField.clear();
        spouse1Field.clear();
        spouse2Field.clear();
        phoneField.clear();
        emailField.clear();
        addressField.clear();
        yearsMarriedField.clear();

        // Clear the fields for the young family form
        youngFamilyFidField.clear();
        youngSpouse1Field.clear();
        youngSpouse2Field.clear();
        youngPhoneField.clear();
        youngEmailField.clear();
        youngAddressField.clear();

        // Clear the fields for the children's details
        child1GenderField.clear();
        child1AgeField.clear();
        child2GenderField.clear();
        child2AgeField.clear();
        child3GenderField.clear();
        child3AgeField.clear();
        child4GenderField.clear();
        child4AgeField.clear();
    }

    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
